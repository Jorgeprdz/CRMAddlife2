// app.js
// AddLife CRM — Enterprise Runtime V11
// Production Hardened Architecture
// Full Runtime + Observability + Performance + Security

console.log('APP VERSION V11 ENTERPRISE OBSERVABILITY');

// ═══════════════════════════════════════════════════════════════
// IMPORTS
// ═══════════════════════════════════════════════════════════════

import { DB } from './db.js';

import {
    showToast
} from './utils.js';

import {
    Runtime
} from './runtime.js';

import {
    SyncRuntime
} from './sync-engine.js';

import {
    IndexedRuntimeDB
} from './indexeddb.js';

import {
    AppStore
} from './store.js';

import {
    PrefetchRuntime
} from './prefetch-engine.js';

import {
    RenderRuntime
} from './render-engine.js';

import {
    IdleEngine
} from './idle-runtime.js';

import {
    Telemetry
} from './telemetry.js';

import {
    PerformanceMonitor
} from './performance-runtime.js';

import {
    CrashRuntimeEngine
} from './crash-runtime.js';

import {
    HealthRuntimeEngine
} from './health-runtime.js';

import {
    Flags
} from './feature-flags.js';

// ═══════════════════════════════════════════════════════════════
// ENVIRONMENT
// ═══════════════════════════════════════════════════════════════

const ENV = Object.freeze({

    APP_NAME:
        'AddLife CRM',

    APP_VERSION:
        '11.0.0',

    DEFAULT_ROUTE:
        'dashboard',

    SUPABASE_URL:
        'https://rmlxigxysujsuwzgoimv.supabase.co',

    // ⚠️ ROTA ESTA KEY EN PRODUCCIÓN
    SUPABASE_KEY:
        'TU_NUEVA_ANON_KEY_ROTADA',

    IS_DEV:

        location.hostname === 'localhost' ||

        location.hostname === '127.0.0.1',

    ENABLE_DEBUG:
        false,

    ENABLE_PREFETCH:
        true,

    ENABLE_SW:
        true,

    ENABLE_SYNC:
        true,

    ENABLE_TELEMETRY:
        true
});

// ═══════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════

const ROUTES = Object.freeze({

    dashboard: () =>
        import('./dashboard.js'),

    prospeccion: () =>
        import('./prospeccion.js'),

    referidos: () =>
        import('./referidos.js'),

    actividad: () =>
        import('./actividad.js'),

    cartera: () =>
        import('./cartera.js'),

    comisiones: () =>
        import('./comisiones.js')
});

// ═══════════════════════════════════════════════════════════════
// SECURITY RUNTIME
// ═══════════════════════════════════════════════════════════════

class SecurityRuntime {

    static init() {

        this.preventIframeEmbedding();

        this.disableEruda();

        this.removeDangerousGlobals();

        this.secureConsole();

        this.freezeCriticalObjects();

        this.detectTampering();
    }

    static preventIframeEmbedding() {

        if (
            window.self !==
            window.top
        ) {

            document.body.innerHTML = '';

            throw new Error(
                'IFRAME_BLOCKED'
            );
        }
    }

    static disableEruda() {

        try {

            if (
                typeof window.eruda !==
                'undefined'
            ) {

                window.eruda.destroy();

                delete window.eruda;
            }

        } catch {}
    }

    static removeDangerousGlobals() {

        try {

            delete window.supabaseClient;

        } catch {}

        Object.defineProperty(
            window,
            'supabaseClient',
            {

                configurable: false,

                enumerable: false,

                get() {

                    console.warn(
                        '[SECURITY] ACCESS BLOCKED'
                    );

                    return undefined;
                },

                set() {

                    console.warn(
                        '[SECURITY] GLOBAL OVERRIDE BLOCKED'
                    );

                    return false;
                }
            }
        );
    }

    static secureConsole() {

        if (ENV.IS_DEV) {
            return;
        }

        const noop = () => {};

        console.log = noop;

        console.debug = noop;

        console.info = noop;
    }

    static freezeCriticalObjects() {

        Object.freeze(ENV);

        Object.freeze(ROUTES);
    }

    static detectTampering() {

        const originalPushState =
            history.pushState;

        history.pushState =
            function (...args) {

                try {

                    return originalPushState.apply(
                        this,
                        args
                    );

                } catch (err) {

                    console.error(
                        '[SECURITY] HISTORY TAMPERING'
                    );

                    throw err;
                }
            };
    }
}

// ═══════════════════════════════════════════════════════════════
// AUTH SERVICE
// ═══════════════════════════════════════════════════════════════

class AuthService {

    #client = null;

    #subscription = null;

    init() {

        if (!window.supabase) {

            console.error(
                '[AUTH] SDK MISSING'
            );

            return false;
        }

        this.#client =
            window.supabase.createClient(

                ENV.SUPABASE_URL,

                ENV.SUPABASE_KEY,

                {

                    auth: {

                        persistSession: true,

                        autoRefreshToken: true,

                        detectSessionInUrl: true,

                        flowType: 'pkce'
                    },

                    global: {

                        headers: {

                            'x-client-info':
                                'addlife-crm'
                        }
                    }
                }
            );

        this.bindAuthEvents();

        return true;
    }

    bindAuthEvents() {

        const {
            data
        } = this.#client
            .auth
            .onAuthStateChange(

                async (
                    event,
                    session
                ) => {

                    if (
                        ENV.ENABLE_TELEMETRY
                    ) {

                        Telemetry.track(

                            'auth_state_change',

                            { event }
                        );
                    }

                    switch (event) {

                        case 'SIGNED_OUT':

                            Runtime.cleanupCurrentRoute();

                            AppStore.clear();

                            window.App.renderLogin();

                            if (
                                ENV.ENABLE_TELEMETRY
                            ) {

                                Telemetry.track(
                                    'logout'
                                );
                            }

                            break;

                        case 'SIGNED_IN':

                            AppStore.set(
                                'user',
                                session?.user || null
                            );

                            if (
                                ENV.ENABLE_TELEMETRY
                            ) {

                                Telemetry.track(
                                    'login_success'
                                );
                            }

                            break;

                        case 'TOKEN_REFRESHED':

                            if (
                                ENV.IS_DEV
                            ) {

                                console.warn(
                                    '[AUTH] TOKEN REFRESHED'
                                );
                            }

                            break;
                    }
                }
            );

        this.#subscription =
            data.subscription;
    }

    async getUser() {

        try {

            const {
                data,
                error
            } = await this.#client
                .auth
                .getUser();

            if (error) {

                throw error;
            }

            return data?.user || null;

        } catch (err) {

            console.error(
                '[AUTH USER ERROR]',
                err
            );

            if (
                ENV.ENABLE_TELEMETRY
            ) {

                Telemetry.track(

                    'auth_get_user_error',

                    {

                        message:
                            err.message
                    }
                );
            }

            return null;
        }
    }

    async login() {

        try {

            await this.#client
                .auth
                .signInWithOAuth({

                    provider: 'google',

                    options: {

                        redirectTo:
                            location.origin,

                        queryParams: {

                            access_type:
                                'offline',

                            prompt:
                                'consent'
                        }
                    }
                });

        } catch (err) {

            console.error(
                '[AUTH LOGIN ERROR]',
                err
            );

            if (
                ENV.ENABLE_TELEMETRY
            ) {

                Telemetry.track(

                    'auth_login_error',

                    {

                        message:
                            err.message
                    }
                );
            }

            showToast(
                'No se pudo iniciar sesión',
                'danger'
            );
        }
    }

    async logout() {

        try {

            Runtime.cleanupCurrentRoute();

            AppStore.clear();

            await this.#client
                .auth
                .signOut();

        } catch (err) {

            console.error(
                '[AUTH LOGOUT ERROR]',
                err
            );

            if (
                ENV.ENABLE_TELEMETRY
            ) {

                Telemetry.track(

                    'auth_logout_error',

                    {

                        message:
                            err.message
                    }
                );
            }

            showToast(
                'Error al cerrar sesión',
                'danger'
            );
        }
    }

    getClient() {

        return this.#client;
    }
}

// ═══════════════════════════════════════════════════════════════
// ROUTER
// ═══════════════════════════════════════════════════════════════

class Router {

    constructor() {

        this.currentRoute = null;

        this.isNavigating = false;
    }

    async navigate(route) {

        if (!ROUTES[route]) {

            showToast(
                'Ruta inválida',
                'danger'
            );

            return;
        }

        if (this.isNavigating) {

            Runtime.abortCurrentNavigation();
        }

        const app =
            document.getElementById(
                'app-content'
            );

        if (!app) {

            throw new Error(
                '#app-content missing'
            );
        }

        const transaction =
            Runtime.startNavigation();

        const {
            navigationId,
            signal
        } = transaction;

        this.isNavigating = true;

        try {

            app.classList.add(
                'route-loading'
            );

            if (
                ENV.ENABLE_TELEMETRY
            ) {

                Telemetry.track(

                    'route_change',

                    { route }
                );
            }

            await PerformanceMonitor
                .measureAsync(

                    `route:${route}`,

                    async () => {

                        const module =
                            await Runtime.safeAsync(

                                Runtime.lazyImport(
                                    ROUTES[route]
                                ),

                                signal
                            );

                        if (
                            Runtime.isNavigationStale(
                                navigationId
                            )
                        ) {

                            return;
                        }

                        const renderName =
                            `render${capitalize(route)}`;

                        const bindName =
                            `bind${capitalize(route)}Events`;

                        const render =
                            module[renderName];

                        const bind =
                            module[bindName];

                        if (
                            typeof render !==
                            'function'
                        ) {

                            throw new Error(
                                `${renderName} missing`
                            );
                        }

                        if (
                            typeof bind !==
                            'function'
                        ) {

                            throw new Error(
                                `${bindName} missing`
                            );
                        }

                        const html =
                            PerformanceMonitor.measure(

                                `${route}_render`,

                                () => render()
                            );

                        if (
                            Runtime.isNavigationStale(
                                navigationId
                            )
                        ) {

                            return;
                        }

                        RenderRuntime
                            .preserveScroll(

                                () => {

                                    const wrapper =
                                        document.createElement(
                                            'div'
                                        );

                                    wrapper.innerHTML =
                                        sanitizeHTMLTemplate(
                                            html
                                        );

                                    app.replaceChildren(
                                        ...wrapper.childNodes
                                    );
                                }
                            );

                        await Runtime.safeAsync(

                            bind({

                                signal,

                                Runtime,

                                AppStore
                            }),

                            signal
                        );

                        if (
                            Runtime.isNavigationStale(
                                navigationId
                            )
                        ) {

                            return;
                        }

                        this.currentRoute =
                            route;

                        this.updateNavigation(
                            route
                        );

                        if (
                            location.hash !==
                            `#${route}`
                        ) {

                            history.pushState(
                                { route },
                                '',
                                `#${route}`
                            );
                        }

                        this.prefetchAdjacentRoutes();
                    }
                );

        } catch (err) {

            if (
                err.name ===
                'AbortError'
            ) {

                return;
            }

            console.error(
                '[ROUTER ERROR]',
                err
            );

            if (
                ENV.ENABLE_TELEMETRY
            ) {

                Telemetry.track(

                    'router_error',

                    {

                        route,

                        message:
                            err.message
                    }
                );
            }

            this.renderError(
                err
            );

        } finally {

            this.isNavigating =
                false;

            app.classList.remove(
                'route-loading'
            );
        }
    }

    updateNavigation(route) {

        document
            .querySelectorAll(
                '.nav-btn'
            )
            .forEach(btn => {

                btn.classList.toggle(

                    'active',

                    btn.dataset.target ===
                    route
                );
            });
    }

    prefetchAdjacentRoutes() {

        if (
            !ENV.ENABLE_PREFETCH
        ) {

            return;
        }

        IdleEngine.schedule(
            () => {

                Object.entries(ROUTES)
                    .forEach(([route, loader]) => {

                        PrefetchRuntime.prefetch(
                            route,
                            loader
                        );
                    });
            }
        );
    }

    renderError(err) {

        const app =
            document.getElementById(
                'app-content'
            );

        if (!app) {
            return;
        }

        app.innerHTML = `

        <section class="fatal-error-screen">

            <div class="fatal-error-icon">
                ⚠️
            </div>

            <h2>
                Error de navegación
            </h2>

            <p>
                ${sanitizeHTML(
                    err.message
                )}
            </p>

            <button
                id="btn-reload-app"
                class="btn-primary"
                type="button"
            >
                Reiniciar
            </button>

        </section>
        `;
    }
}

// ═══════════════════════════════════════════════════════════════
// APP MANAGER
// ═══════════════════════════════════════════════════════════════

class AppManager {

    constructor() {

        this.auth =
            new AuthService();

        this.router =
            new Router();

        this.initialized =
            false;

        this.bindGlobalEvents();

        this.bindBrowserEvents();
    }

    async init() {

        if (this.initialized) {
            return;
        }

        try {

            SecurityRuntime.init();

            if (
                ENV.ENABLE_TELEMETRY
            ) {

                Telemetry.init();

                CrashRuntimeEngine.init();

                HealthRuntimeEngine.init();

                await Flags.load();

                Telemetry.track(
                    'app_bootstrap_started'
                );
            }

            await DB.init();

            await IndexedRuntimeDB.init();

            if (
                ENV.ENABLE_SYNC
            ) {

                SyncRuntime.init();

                if (
                    ENV.ENABLE_TELEMETRY
                ) {

                    Telemetry.track(
                        'sync_runtime_initialized'
                    );
                }
            }

            const authReady =
                this.auth.init();

            if (!authReady) {

                throw new Error(
                    'AUTH_INIT_FAILED'
                );
            }

            const user =
                await this.auth
                    .getUser();

            if (!user) {

                this.renderLogin();

                return;
            }

            AppStore.set(
                'user',
                user
            );

            this.enableAuthenticatedUI();

            const route =
                location.hash
                    .replace('#', '') ||

                ENV.DEFAULT_ROUTE;

            await this.router
                .navigate(route);

            this.initialized =
                true;

            if (
                ENV.ENABLE_TELEMETRY
            ) {

                Telemetry.track(

                    'app_initialized',

                    {

                        version:
                            ENV.APP_VERSION
                    }
                );
            }

        } catch (err) {

            console.error(
                '[APP INIT ERROR]',
                err
            );

            if (
                ENV.ENABLE_TELEMETRY
            ) {

                Telemetry.track(

                    'app_init_error',

                    {

                        message:
                            err.message
                    }
                );
            }

            this.renderFatalError(
                err
            );
        }
    }

    enableAuthenticatedUI() {

        document
            .getElementById(
                'main-sidebar'
            )
            ?.style
            .setProperty(
                'display',
                'flex'
            );

        document
            .getElementById(
                'ai-chat-bubble'
            )
            ?.style
            .setProperty(
                'display',
                'flex'
            );
    }

    renderLogin() {

        Runtime.cleanupCurrentRoute();

        const app =
            document.getElementById(
                'app-content'
            );

        if (!app) {
            return;
        }

        app.innerHTML = `

        <section class="login-screen">

            <div class="login-card">

                <div class="login-logo">
                    🚀
                </div>

                <h1>
                    ${ENV.APP_NAME}
                </h1>

                <p>
                    Plataforma comercial profesional
                </p>

                <button
                    id="btn-login-core"
                    class="btn-primary"
                    type="button"
                >
                    Ingresar con Google
                </button>

            </div>

        </section>
        `;
    }

    renderFatalError(err) {

        const app =
            document.getElementById(
                'app-content'
            );

        if (!app) {
            return;
        }

        app.innerHTML = `

        <section class="fatal-error-screen">

            <div class="fatal-error-icon">
                💥
            </div>

            <h2>
                Error crítico
            </h2>

            <p>
                ${sanitizeHTML(
                    err.message
                )}
            </p>

            <button
                id="btn-reload-app"
                class="btn-primary"
                type="button"
            >
                Reiniciar aplicación
            </button>

        </section>
        `;
    }

    bindGlobalEvents() {

        document.body
            .addEventListener(

                'click',

                async e => {

                    const nav =
                        e.target.closest(
                            '.nav-btn'
                        );

                    if (nav) {

                        const route =
                            nav.dataset.target;

                        await this.router
                            .navigate(route);

                        return;
                    }

                    if (
                        e.target.id ===
                        'btn-login-core'
                    ) {

                        await this.auth
                            .login();

                        return;
                    }

                    if (
                        e.target.id ===
                        'btn-reload-app'
                    ) {

                        location.reload();

                        return;
                    }

                    if (
                        e.target.matches(
                            '[data-logout]'
                        )
                    ) {

                        await this.auth
                            .logout();
                    }
                },

                {
                    passive: true
                }
            );

        document.body
            .addEventListener(

                'mouseenter',

                e => {

                    const nav =
                        e.target.closest(
                            '.nav-btn'
                        );

                    if (!nav) {
                        return;
                    }

                    const route =
                        nav.dataset.target;

                    if (
                        !route ||
                        !ROUTES[route]
                    ) {

                        return;
                    }

                    PrefetchRuntime.prefetch(
                        route,
                        ROUTES[route]
                    );
                },

                true
            );
    }

    bindBrowserEvents() {

        window.addEventListener(
            'popstate',

            async () => {

                const route =
                    location.hash
                        .replace('#', '') ||

                    ENV.DEFAULT_ROUTE;

                await this.router
                    .navigate(route);
            }
        );

        window.addEventListener(
            'online',

            () => {

                showToast(
                    'Conexión restaurada',
                    'success'
                );

                if (
                    ENV.ENABLE_TELEMETRY
                ) {

                    Telemetry.track(
                        'online'
                    );
                }

                SyncRuntime.processQueue();
            }
        );

        window.addEventListener(
            'offline',

            () => {

                showToast(
                    'Modo offline',
                    'warning'
                );

                if (
                    ENV.ENABLE_TELEMETRY
                ) {

                    Telemetry.track(
                        'offline'
                    );
                }
            }
        );

        document.addEventListener(
            'visibilitychange',

            () => {

                if (
                    document.visibilityState ===
                    'visible'
                ) {

                    SyncRuntime.processQueue();

                    if (
                        ENV.ENABLE_TELEMETRY
                    ) {

                        Telemetry.track(
                            'app_visible'
                        );
                    }
                }
            }
        );
    }
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

function capitalize(value) {

    return (
        value.charAt(0)
            .toUpperCase() +

        value.slice(1)
    );
}

function sanitizeHTML(value) {

    return String(value ?? '')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function sanitizeHTMLTemplate(html) {

    const parser =
        new DOMParser();

    const doc =
        parser.parseFromString(
            html,
            'text/html'
        );

    doc
        .querySelectorAll(
            'script'
        )
        .forEach(script => {

            script.remove();
        });

    return doc.body.innerHTML;
}

// ═══════════════════════════════════════════════════════════════
// GLOBAL APP
// ═══════════════════════════════════════════════════════════════

window.App =
    new AppManager();

// ═══════════════════════════════════════════════════════════════
// STARTUP
// ═══════════════════════════════════════════════════════════════

document.addEventListener(
    'DOMContentLoaded',

    async () => {

        await window.App.init();
    }
);

// ═══════════════════════════════════════════════════════════════
// SERVICE WORKER
// ═══════════════════════════════════════════════════════════════

if (
    'serviceWorker' in navigator &&
    ENV.ENABLE_SW
) {

    window.addEventListener(
        'load',

        async () => {

            try {

                const registration =
                    await navigator
                        .serviceWorker
                        .register(
                            '/service-worker.js'
                        );

                if (
                    ENV.ENABLE_TELEMETRY
                ) {

                    Telemetry.track(
                        'service_worker_registered'
                    );
                }

                registration.addEventListener(
                    'updatefound',

                    () => {

                        const worker =
                            registration.installing;

                        if (!worker) {
                            return;
                        }

                        worker.addEventListener(
                            'statechange',

                            () => {

                                if (
                                    worker.state ===
                                    'installed'
                                ) {

                                    if (
                                        navigator
                                            .serviceWorker
                                            .controller
                                    ) {

                                        showToast(
                                            'Nueva versión disponible',
                                            'info'
                                        );

                                        if (
                                            ENV.ENABLE_TELEMETRY
                                        ) {

                                            Telemetry.track(
                                                'service_worker_update_available'
                                            );
                                        }
                                    }
                                }
                            }
                        );
                    }
                );

            } catch (err) {

                console.error(
                    '[SW ERROR]',
                    err
                );

                if (
                    ENV.ENABLE_TELEMETRY
                ) {

                    Telemetry.track(

                        'service_worker_error',

                        {

                            message:
                                err.message
                        }
                    );
                }
            }
        }
    );
}